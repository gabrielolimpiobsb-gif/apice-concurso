import React, { useMemo, useState } from 'react';
import { Performance, Question } from '../types';
import { 
  Target, BarChart2, CheckCircle2, XCircle, Brain, Activity, 
  TrendingUp, TrendingDown, ChevronRight, Layers, 
  AlertTriangle, Clock, Calendar, ArrowLeft, Zap, Trophy, Shield, Database
} from 'lucide-react';
import { cn } from '../lib/utils';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, BarChart, Bar, Cell, AreaChart, Area } from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { storageService } from '../services/storageService';

interface EnrichedPerformance extends Performance {
  board: string;
  year: number | string;
  difficulty: string;
  discipline: string;
  topic: string;
}

interface AnalyticsScreenProps {
  performance: Performance[];
  questions?: Question[];
  onReset: () => void;
  calculateStats: () => any[];
  onBack: () => void;
}

export const AnalyticsScreen: React.FC<AnalyticsScreenProps> = ({ 
  performance, 
  questions = [], 
  onBack 
}) => {
  const [periodFilter, setPeriodFilter] = useState<'7d' | '30d' | '90d' | 'all'>('all');
  const [selectedDiscipline, setSelectedDiscipline] = useState<string | null>(null);

  // 1. Data Enrichment & Filtering
  const { filteredData, allTimeData } = useMemo(() => {
    const enriched: EnrichedPerformance[] = performance.map(p => {
      const q = questions.find(q => q.id === p.questionId);
      return {
        ...p,
        board: q?.board || 'Desconhecida',
        year: q?.year || 'N/A',
        difficulty: q?.difficulty || 'N/A',
        discipline: q?.discipline || p.discipline || 'Desconhecida',
        topic: q?.topic || p.topic || 'Desconhecido',
      };
    });

    const now = new Date().getTime();
    const periodMs = {
      '7d': 7 * 24 * 60 * 60 * 1000,
      '30d': 30 * 24 * 60 * 60 * 1000,
      '90d': 90 * 24 * 60 * 60 * 1000,
      'all': Infinity
    }[periodFilter];

    const filtered = enriched.filter(p => {
      const pTime = new Date(p.answeredAt).getTime();
      return (now - pTime) <= periodMs;
    });

    return { filteredData: filtered, allTimeData: enriched };
  }, [performance, questions, periodFilter]);

  // 2. Core Stats Calculation
  const stats = useMemo(() => {
    const total = filteredData.length;
    const correct = filteredData.filter(p => p.isCorrect).length;
    const incorrect = total - correct;
    const accuracy = total > 0 ? (correct / total) * 100 : 0;
    
    // Previous period for trend
    const now = new Date().getTime();
    const periodMs = {
      '7d': 7 * 24 * 60 * 60 * 1000,
      '30d': 30 * 24 * 60 * 60 * 1000,
      '90d': 90 * 24 * 60 * 60 * 1000,
      'all': Infinity
    }[periodFilter];
    
    let prevAccuracy = 0;
    if (periodFilter !== 'all') {
      const prevData = allTimeData.filter(p => {
        const pTime = new Date(p.answeredAt).getTime();
        return (now - pTime) > periodMs && (now - pTime) <= (periodMs * 2);
      });
      const prevCorrect = prevData.filter(p => p.isCorrect).length;
      prevAccuracy = prevData.length > 0 ? (prevCorrect / prevData.length) * 100 : 0;
    }

    const accuracyTrend = accuracy - prevAccuracy;

    // Subject breakdown
    const byDiscipline = filteredData.reduce((acc, p) => {
      if (!acc[p.discipline]) acc[p.discipline] = { total: 0, correct: 0, topics: {} };
      acc[p.discipline].total++;
      if (p.isCorrect) acc[p.discipline].correct++;
      
      if (!acc[p.discipline].topics[p.topic]) {
        acc[p.discipline].topics[p.topic] = { total: 0, correct: 0 };
      }
      acc[p.discipline].topics[p.topic].total++;
      if (p.isCorrect) acc[p.discipline].topics[p.topic].correct++;
      
      return acc;
    }, {} as Record<string, any>);

    const disciplinesArray = Object.entries(byDiscipline).map(([name, data]: any) => ({
      name,
      total: data.total,
      correct: data.correct,
      accuracy: (data.correct / data.total) * 100,
      topics: Object.entries(data.topics).map(([tName, tData]: any) => ({
        name: tName,
        total: tData.total,
        correct: tData.correct,
        accuracy: (tData.correct / tData.total) * 100,
      }))
    })).sort((a, b) => b.total - a.total);

    // Performance Index (0-100)
    // Formula: Accuracy (60%) + Consistency/Volume (20%) + Trend (20%)
    let index = 0;
    if (total > 0) {
      const volScore = Math.min(total / (periodFilter === '7d' ? 50 : 200), 1) * 20;
      const accScore = (accuracy / 100) * 60;
      const trendScore = Math.max(0, Math.min((accuracyTrend + 10) / 20, 1)) * 20;
      index = Math.round(volScore + accScore + trendScore);
    }


    // Temporal data (last 7 days or based on period)
    const timeSeriesMap = new Map<string, { total: number, correct: number, date: string }>();
    
    // Group by day (YYYY-MM-DD)
    filteredData.forEach(p => {
      const d = new Date(p.answeredAt);
      const day = d.toISOString().split('T')[0];
      if (!timeSeriesMap.has(day)) {
        timeSeriesMap.set(day, { total: 0, correct: 0, date: day });
      }
      const dayData = timeSeriesMap.get(day)!;
      dayData.total++;
      if (p.isCorrect) dayData.correct++;
    });

    const timeSeries = Array.from(timeSeriesMap.values()).sort((a, b) => a.date.localeCompare(b.date)).map(d => ({
      name: d.date.split('-').slice(1).reverse().join('/'),
      accuracy: (d.correct / d.total) * 100,
      total: d.total
    }));

    
    const byBoard = filteredData.reduce((acc, p) => {
      const b = p.board || 'Desconhecida';
      if (!acc[b]) acc[b] = { total: 0, correct: 0 };
      acc[b].total++;
      if (p.isCorrect) acc[b].correct++;
      return acc;
    }, {} as Record<string, any>);

    const boardsArray = Object.entries(byBoard).map(([name, data]: any) => ({
      name,
      total: data.total,
      correct: data.correct,
      accuracy: (data.correct / data.total) * 100
    })).sort((a, b) => b.total - a.total).slice(0, 3);

    const byDiff = filteredData.reduce((acc, p) => {
      const d = p.difficulty || 'Desconhecida';
      if (!acc[d]) acc[d] = { total: 0, correct: 0 };
      acc[d].total++;
      if (p.isCorrect) acc[d].correct++;
      return acc;
    }, {} as Record<string, any>);

    const diffArray = Object.entries(byDiff).map(([name, data]: any) => ({
      name,
      total: data.total,
      correct: data.correct,
      accuracy: (data.correct / data.total) * 100
    })).sort((a, b) => b.total - a.total);

    return { total, correct, incorrect, accuracy, accuracyTrend, disciplinesArray, index, timeSeries, boardsArray, diffArray };


  }, [filteredData, allTimeData, periodFilter]);

  // Generate AI Insights
  const insights = useMemo(() => {
    if (stats.total < 10) return [
      { type: 'warning', title: 'Dados insuficientes', desc: 'Responda mais questões para gerar análises precisas.' }
    ];

    const alerts = [];
    
    if (stats.accuracyTrend > 5) {
      alerts.push({ type: 'success', title: 'Evolução', desc: `Seu desempenho aumentou ${stats.accuracyTrend.toFixed(1)}% neste período.` });
    } else if (stats.accuracyTrend < -5) {
      alerts.push({ type: 'danger', title: 'Queda de Rendimento', desc: `Sua taxa de acerto caiu ${Math.abs(stats.accuracyTrend).toFixed(1)}%.` });
    }

    const weakestSubjects = [...stats.disciplinesArray].filter(d => d.total >= 5).sort((a, b) => a.accuracy - b.accuracy);
    if (weakestSubjects.length > 0 && weakestSubjects[0].accuracy < 60) {
      alerts.push({ 
        type: 'warning', 
        title: 'Prioridade', 
        desc: `Revise ${weakestSubjects[0].name}. Seu aproveitamento está em ${weakestSubjects[0].accuracy.toFixed(1)}%.` 
      });
    }

    if (alerts.length === 0) {
      alerts.push({ type: 'info', title: 'Consistência', desc: 'Você está mantendo um ritmo constante de estudos. Continue assim!' });
    }

    return alerts;
  }, [stats]);

  // We need to render the UI...

  const getMasteryLevel = (acc: number) => {
    if (acc >= 85) return { label: 'Excelente', color: 'text-emerald-500', bg: 'bg-emerald-500/10' };
    if (acc >= 70) return { label: 'Bom', color: 'text-blue-500', bg: 'bg-blue-500/10' };
    if (acc >= 55) return { label: 'Regular', color: 'text-yellow-500', bg: 'bg-yellow-500/10' };
    if (acc >= 40) return { label: 'Atenção', color: 'text-orange-500', bg: 'bg-orange-500/10' };
    return { label: 'Crítico', color: 'text-rose-500', bg: 'bg-rose-500/10' };
  };

  return (
    <div className="flex-1 overflow-x-hidden overflow-y-auto no-scrollbar pb-32 bg-[#f9fafc] dark:bg-[#01142e]">
      {/* Header */}
      <header className="bg-gradient-to-b from-white dark:from-[#0a2346] to-[#f9fafc] dark:to-[#01142e] p-6 border-b border-purple-500/10 sticky top-0 z-30">
        <div className="max-w-4xl mx-auto w-full flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
             <button onClick={onBack} className="w-10 h-10 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-xl flex items-center justify-center text-black dark:text-white hover:bg-black/10 transition-colors">
               <ArrowLeft size={20} />
             </button>
             <div>
               <h1 className="text-xl font-black text-black dark:text-white uppercase tracking-tight">Estatísticas</h1>
               <p className="text-xs text-black/50 dark:text-white/50 font-bold uppercase tracking-widest">Dashboard Inteligente</p>
             </div>
          </div>
          <div className="flex bg-black/5 dark:bg-white/5 p-1 rounded-xl border border-black/10 dark:border-white/10 overflow-x-auto w-full sm:w-auto no-scrollbar justify-between sm:justify-start">
            {['7d', '30d', '90d', 'all'].map(p => (
              <button 
                key={p} 
                onClick={() => setPeriodFilter(p as any)}
                className={cn("px-3 py-1.5 rounded-lg text-xs font-bold transition-all", periodFilter === p ? "bg-purple-500 text-white shadow-sm" : "text-black/60 dark:text-white/60 hover:text-black")}
              >
                {p === '7d' ? '7D' : p === '30d' ? '30D' : p === '90d' ? '3M' : 'TUDO'}
              </button>
            ))}
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto w-full px-4 py-6 space-y-6">
        
        {/* Performance Index & Overview */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
           <div className="md:col-span-1 bg-gradient-to-br from-purple-600 to-indigo-600 rounded-3xl p-6 text-white relative overflow-hidden shadow-xl shadow-purple-500/20">
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 blur-[30px] rounded-full -translate-y-1/2 translate-x-1/2" />
              <h3 className="font-bold uppercase tracking-widest text-xs text-white/80 mb-4">Índice de Desempenho</h3>
              <div className="flex items-end gap-2 mb-2">
                 <span className="text-6xl font-black tracking-tighter leading-none">{stats.index}</span>
                 <span className="text-xl font-bold text-white/60 mb-1">/100</span>
              </div>
              <div className="h-1.5 w-full bg-white/20 rounded-full overflow-hidden mt-4">
                 <div className="h-full bg-white rounded-full transition-all duration-1000" style={{ width: `${stats.index}%` }} />
              </div>
           </div>

           <div className="md:col-span-2 grid grid-cols-2 gap-4">
              <div className="bg-white dark:bg-[#0a2346] rounded-3xl p-5 border border-black/5 dark:border-white/5 flex flex-col justify-center">
                 <div className="flex items-center gap-2 text-black/50 dark:text-white/50 mb-2">
                    <Target size={16} /> <span className="text-xs font-bold uppercase tracking-widest">Taxa de Acerto</span>
                 </div>
                 <div className="flex items-end gap-2">
                    <span className="text-3xl font-black text-black dark:text-white">{stats.accuracy.toFixed(1)}%</span>
                    {stats.accuracyTrend !== 0 && (
                      <span className={cn("text-xs font-bold mb-1 flex items-center", stats.accuracyTrend > 0 ? "text-emerald-500" : "text-rose-500")}>
                        {stats.accuracyTrend > 0 ? <TrendingUp size={12} className="mr-0.5" /> : <TrendingDown size={12} className="mr-0.5" />}
                        {Math.abs(stats.accuracyTrend).toFixed(1)}%
                      </span>
                    )}
                 </div>
              </div>
              <div className="bg-white dark:bg-[#0a2346] rounded-3xl p-5 border border-black/5 dark:border-white/5 flex flex-col justify-center">
                 <div className="flex items-center gap-2 text-black/50 dark:text-white/50 mb-2">
                    <Layers size={16} /> <span className="text-xs font-bold uppercase tracking-widest">Questões</span>
                 </div>
                 <div className="flex items-end gap-2">
                    <span className="text-3xl font-black text-black dark:text-white">{stats.total}</span>
                 </div>
                 <div className="flex items-center gap-3 mt-2 text-xs font-bold">
                    <span className="text-emerald-500">{stats.correct} certas</span>
                    <span className="text-rose-500">{stats.incorrect} erradas</span>
                 </div>
              </div>
           </div>
        </section>

        {/* O Ápice Analisou */}
        {insights.length > 0 && (
          <section className="bg-purple-500/5 border border-purple-500/20 rounded-3xl p-6">
            <h2 className="text-sm font-black text-purple-600 dark:text-purple-400 uppercase tracking-widest mb-4 flex items-center gap-2">
              <Brain size={18} /> O Ápice analisou seu desempenho
            </h2>
            <div className="grid gap-3">
              {insights.map((insight, idx) => (
                <div key={idx} className="flex gap-4 items-start bg-white dark:bg-[#0a2346] p-4 rounded-2xl border border-black/5 dark:border-white/5">
                   <div className={cn("p-2 rounded-xl shrink-0", 
                     insight.type === 'warning' ? "bg-orange-500/10 text-orange-500" : 
                     insight.type === 'success' ? "bg-emerald-500/10 text-emerald-500" : 
                     insight.type === 'danger' ? "bg-rose-500/10 text-rose-500" : "bg-blue-500/10 text-blue-500"
                   )}>
                     {insight.type === 'warning' && <AlertTriangle size={18} />}
                     {insight.type === 'success' && <TrendingUp size={18} />}
                     {insight.type === 'danger' && <TrendingDown size={18} />}
                     {insight.type === 'info' && <Activity size={18} />}
                   </div>
                   <div>
                     <h4 className="text-sm font-bold text-black dark:text-white mb-0.5">{insight.title}</h4>
                     <p className="text-sm text-black/60 dark:text-white/60 leading-snug">{insight.desc}</p>
                   </div>
                </div>
              ))}
            </div>
          </section>
        )}


        {/* Temporal Evolution */}
        <section className="bg-white dark:bg-[#0a2346] rounded-3xl p-6 border border-black/5 dark:border-white/5">
           <h2 className="text-sm font-black text-black dark:text-white uppercase tracking-widest mb-6 flex items-center gap-2">
              <Activity size={18} className="text-blue-500" /> Evolução do Desempenho
           </h2>
           <div className="h-64 w-full min-w-0">
              <ResponsiveContainer width="100%" height="100%">
                 <AreaChart data={stats.timeSeries}>
                   <defs>
                     <linearGradient id="colorAcc" x1="0" y1="0" x2="0" y2="1">
                       <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                       <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                     </linearGradient>
                   </defs>
                   <CartesianGrid strokeDasharray="3 3" opacity={0.1} vertical={false} />
                   <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                   <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10 }} />
                   <RechartsTooltip 
                     contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)' }}
                   />
                   <Area type="monotone" dataKey="accuracy" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorAcc)" />
                 </AreaChart>
              </ResponsiveContainer>
           </div>
        </section>

        {/* Desempenho por Matéria */}
        <section className="space-y-4">
           <h2 className="text-sm font-black text-black dark:text-white uppercase tracking-widest flex items-center gap-2">
              <Database size={18} className="text-purple-500" /> Desempenho por Matéria
           </h2>
           
           <div className="grid gap-3">
             {stats.disciplinesArray.map((disc, idx) => {
               const mastery = getMasteryLevel(disc.accuracy);
               const isExpanded = selectedDiscipline === disc.name;
               return (
                 <div key={idx} className="bg-white dark:bg-[#0a2346] border border-black/5 dark:border-white/5 rounded-2xl overflow-hidden transition-all">
                   <button 
                     onClick={() => setSelectedDiscipline(isExpanded ? null : disc.name)}
                     className="w-full p-4 flex items-center gap-4 hover:bg-black/5 dark:hover:bg-white/5 transition-colors text-left"
                   >
                     <div className="flex-1">
                       <div className="flex justify-between items-start mb-2">
                         <h3 className="font-bold text-black dark:text-white text-sm leading-tight">{disc.name}</h3>
                         <span className={cn("text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-md whitespace-nowrap", mastery.bg, mastery.color)}>
                           {mastery.label}
                         </span>
                       </div>
                       <div className="flex items-center gap-4 text-xs font-bold text-black/50 dark:text-white/50">
                          <span>{disc.accuracy.toFixed(1)}% acerto</span>
                          <span>{disc.total} questões</span>
                       </div>
                     </div>
                     <ChevronRight size={20} className={cn("text-black/30 dark:text-white/30 transition-transform", isExpanded && "rotate-90")} />
                   </button>
                   
                   <AnimatePresence>
                     {isExpanded && (
                       <motion.div 
                         initial={{ height: 0 }} 
                         animate={{ height: 'auto' }} 
                         exit={{ height: 0 }}
                         className="overflow-hidden"
                       >
                         <div className="p-4 pt-0 border-t border-black/5 dark:border-white/5 bg-black/[0.02] dark:bg-white/[0.02]">
                           <h4 className="text-[10px] uppercase font-bold tracking-widest text-black/40 dark:text-white/40 mb-3 mt-3">Análise por Assunto</h4>
                           <div className="space-y-3">
                             {disc.topics.sort((a: any, b: any) => a.accuracy - b.accuracy).map((topic: any, tIdx: number) => {
                               const tMastery = getMasteryLevel(topic.accuracy);
                               return (
                                 <div key={tIdx} className="flex flex-col gap-1.5">
                                   <div className="flex justify-between items-center text-xs">
                                     <span className="font-semibold text-black dark:text-white truncate pr-2">{topic.name}</span>
                                     <span className={cn("font-bold", tMastery.color)}>{topic.accuracy.toFixed(1)}%</span>
                                   </div>
                                   <div className="flex items-center gap-2">
                                     <div className="flex-1 h-1.5 bg-black/5 dark:bg-white/10 rounded-full overflow-hidden">
                                       <div className={cn("h-full rounded-full", tMastery.bg.replace('/10', '').replace('bg-', 'bg-'))} style={{ width: `${topic.accuracy}%` }} />
                                     </div>
                                     <span className="text-[9px] font-bold text-black/40 dark:text-white/40">{topic.total}q</span>
                                   </div>
                                 </div>
                               )
                             })}
                           </div>
                         </div>
                       </motion.div>
                     )}
                   </AnimatePresence>
                 </div>
               )
             })}
           </div>
        </section>


        {/* Priority / Onde mais erra */}
        <section className="space-y-4">
           <h2 className="text-sm font-black text-black dark:text-white uppercase tracking-widest flex items-center gap-2">
              <Zap size={18} className="text-rose-500" /> Onde você mais erra
           </h2>
           <div className="grid gap-3">
             {stats.disciplinesArray.flatMap((d: any) => d.topics.map((t: any) => ({ ...t, discipline: d.name })))
               .filter((t: any) => t.total >= 3 && t.accuracy < 60)
               .sort((a: any, b: any) => a.accuracy - b.accuracy)
               .slice(0, 5)
               .map((topic: any, idx: number) => {
                 // Priority score algorithm: Lower accuracy & higher total = higher priority
                 const errorRate = 100 - topic.accuracy;
                 const priorityScore = Math.min(Math.round((errorRate * 0.7) + (Math.min(topic.total, 50) * 0.6)), 99);
                 
                 return (
                 <div key={idx} className="bg-rose-50 dark:bg-rose-500/5 border border-rose-100 dark:border-rose-500/10 rounded-2xl p-4 flex gap-4 items-center">
                   <div className="w-12 h-12 bg-white dark:bg-[#0a2346] rounded-xl flex items-center justify-center font-black text-lg text-rose-500 shadow-sm border border-black/5 dark:border-white/5 shrink-0">
                     {idx + 1}
                   </div>
                   <div className="flex-1 min-w-0">
                     <p className="text-[10px] uppercase font-bold tracking-widest text-rose-500 mb-0.5 truncate">{topic.discipline}</p>
                     <h4 className="font-bold text-sm text-black dark:text-white truncate">{topic.name}</h4>
                     <div className="flex items-center gap-3 mt-1.5 text-xs font-bold text-black/60 dark:text-white/60">
                       <span className="text-rose-500">{topic.accuracy.toFixed(1)}% acerto</span>
                       <span>{topic.total - topic.correct} erros</span>
                     </div>
                   </div>
                   <div className="text-center shrink-0">
                     <div className="text-[10px] uppercase font-black tracking-widest text-black/40 dark:text-white/40 mb-0.5">Prioridade</div>
                     <div className={cn("text-lg font-black", priorityScore > 80 ? "text-rose-500" : "text-orange-500")}>{priorityScore}</div>
                   </div>
                 </div>
               )})}
           </div>
        </section>

        
        {/* Bancas e Dificuldade */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
           {/* Bancas */}
           <div className="bg-white dark:bg-[#0a2346] rounded-3xl p-6 border border-black/5 dark:border-white/5">
             <h2 className="text-xs font-black text-black/50 dark:text-white/50 uppercase tracking-widest mb-4">Desempenho por Banca</h2>
             <div className="space-y-3">
               {stats.boardsArray.length > 0 ? stats.boardsArray.map((b: any, idx: number) => (
                 <div key={idx} className="flex items-center justify-between">
                    <span className="font-bold text-sm text-black dark:text-white">{b.name}</span>
                    <span className="text-xs font-bold px-2 py-1 bg-black/5 dark:bg-white/5 rounded-md">{b.accuracy.toFixed(1)}%</span>
                 </div>
               )) : <div className="text-xs text-black/40">Dados insuficientes</div>}
             </div>
           </div>

           {/* Dificuldade */}
           <div className="bg-white dark:bg-[#0a2346] rounded-3xl p-6 border border-black/5 dark:border-white/5">
             <h2 className="text-xs font-black text-black/50 dark:text-white/50 uppercase tracking-widest mb-4">Nível de Dificuldade</h2>
             <div className="space-y-3">
               {stats.diffArray.length > 0 ? stats.diffArray.map((d: any, idx: number) => (
                 <div key={idx} className="flex items-center justify-between">
                    <span className="font-bold text-sm text-black dark:text-white">{d.name}</span>
                    <span className={cn("text-xs font-bold px-2 py-1 rounded-md", getMasteryLevel(d.accuracy).bg, getMasteryLevel(d.accuracy).color)}>{d.accuracy.toFixed(1)}%</span>
                 </div>
               )) : <div className="text-xs text-black/40">Dados insuficientes</div>}
             </div>
           </div>
        </section>

        {/* Flashcards Overview */}
        <section className="space-y-4">
           <h2 className="text-sm font-black text-black dark:text-white uppercase tracking-widest flex items-center gap-2 mt-4">
              <Layers size={18} className="text-blue-500" /> Desempenho em Flashcards
           </h2>
           <div className="bg-white dark:bg-[#0a2346] rounded-3xl p-6 border border-black/5 dark:border-white/5">
             <div className="flex justify-between items-center mb-6">
                <div>
                   <h3 className="font-bold text-black dark:text-white text-lg">Visão Geral</h3>
                   <p className="text-xs text-black/50 dark:text-white/50 font-bold uppercase">Baseado nas suas revisões</p>
                </div>
                <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500">
                  <Brain size={24} />
                </div>
             </div>
             
             {(() => {
                const flashStats = storageService.getFlashcardStats();
                const total = flashStats?.total || 0;
                const correct = flashStats?.correct || 0;
                const acc = total > 0 ? (correct / total) * 100 : 0;
                
                if (total === 0) {
                  return (
                    <div className="text-center py-6">
                      <div className="text-black/30 dark:text-white/30 font-bold text-sm">Nenhuma revisão registrada ainda.</div>
                      <p className="text-xs text-black/40 dark:text-white/40 mt-1">Estude seus flashcards para ver seu desempenho aqui.</p>
                    </div>
                  );
                }

                return (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-black/5 dark:bg-white/5 p-4 rounded-2xl">
                       <div className="text-[10px] uppercase font-bold tracking-widest text-black/50 dark:text-white/50 mb-1">Taxa de Acerto</div>
                       <div className="text-2xl font-black text-blue-500">{acc.toFixed(1)}%</div>
                    </div>
                    <div className="bg-black/5 dark:bg-white/5 p-4 rounded-2xl">
                       <div className="text-[10px] uppercase font-bold tracking-widest text-black/50 dark:text-white/50 mb-1">Total Revisado</div>
                       <div className="text-2xl font-black text-black dark:text-white">{total}</div>
                    </div>
                  </div>
                );
             })()}
           </div>
        </section>

      </div>
    </div>
  );
};
